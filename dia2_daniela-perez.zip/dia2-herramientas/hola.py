print("hola, soy un programa desde python")
print(2+3*4)
print(mensaje_secreto)
print("¿llegaré a ejecutarme?")
