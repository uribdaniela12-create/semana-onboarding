seccion 1
version ubuntu:
ubuntu 26.04.1 Lts

version python:
Python 3.14.4

donde esta instalado:
/usr/bin/python3

cual es la difeerencia entre un compilador y un interprete?
el compilador traduce el codigo antes de ejecutarlo y el interprete lo ejecuta con cada instruccion

Que paso en la linea 4 de hola.py ?
que python se detubo en la linea 4 ya que la informacion que se mando a llamar no estaba definida y por eso arrojo el error

clasificacion de herramientas
ubuntu: sistema operativo
vs code: editor de codigo
python: interprete
chrome:navegador
gcc: copilador

seccion 2
como estaba instalado vs code?
la instalacion la comprobe con which code y me arrojo una direccion ya que estoy trabajando con wsl
"/mnt/c/Users/Usuario/AppData/Local/Programs/Microsoft VS Code/bin/code"

por que es importante instalar programas desde una fuente oficial?
porque permite descargar una version mas reciente y confiable y es menos riego de que en el vengan archivos maliciosos

Que pasa con la configuracion al desinstalar vd code?
nada, como la configuracion no se pierde ni los datos ni proyectos

seccion 3

Un perfil de VS Code es como tener una configuración diferente dentro del mismo programa.
Cada perfil puede tener extensiones y opciones diferentes.
Los archivos del proyecto siguen siendo los mismos, pero pueden cambiar los íconos o algunas ayudas del editor.
VS Code pregunta si confío en el publicador porque las extensiones pueden hacer cambios dentro del programa y es mejor instalar cosas seguras.


seccion 4

En Perfil2-Basico el auto guardado estaba apagado y tenía que usar `Ctrl + S`.

En Perfil1-Pro los cambios se guardaban solos.

En Perfil2-Basico las etiquetas no cambiaban automáticamente.

En Perfil1-Pro, cuando cambiaba una etiqueta, la otra también cambiaba.

En Perfil2-Basico los errores se veían más que todo en Problemas.

En Perfil1-Pro, Error Lens mostraba el error directamente en el código.

Perfil2-Basico tenía los íconos normales.

Perfil1-Pro tenía Material Icon Theme y era más fácil diferenciar los archivos.

Perfil2-Basico tenía 21 extensiones corriendo.

Perfil1-Pro tenía 25.

Reflexion

Sí noté diferencia entre los dos perfiles. El Perfil1-Pro tenía más ayudas y hacía algunas cosas automáticamente.

Tener varios perfiles sirve para organizar mejor VS Code dependiendo del trabajo que uno esté haciendo.

Las extensiones ayudan mucho porque facilitan tareas y muestran errores más rápido, pero tener demasiadas también puede hacer que el editor use más recursos.

En un trabajo se podría tener un perfil para desarrollo web y otro para Python, por ejemplo.


seccion 5

La página que usé fue Wikipedia de Medellín.

Algunas etiquetas que encontré fueron:

   `<h1>` para el título principal.
   `<p>` para los párrafos.
   `<a>` para los enlaces.
   `<img>` para las imágenes.
   `<div>` para agrupar contenido.

Cuando recargué la página, los cambios desaparecieron porque solo los había hecho desde DevTools y no en los archivos reales.

El DOM es como la forma en que el navegador organiza y muestra el HTML de una página para poder trabajar con él.



seccion 6

`2 + 3` dio 5.

`10 - 4 * 2` dio 2.

`(10 - 4) * 2` dio 12.

`10 / 4` dio 2.5.

`10 % 3` dio 1.

`2 ** 8` dio 256.

`120000 * 0.19` dio 22800.

`365 * 24` dio 8760.

 `0.1 + 0.2` no da exactamente 0.3 porque los computadores manejan algunos decimales de forma aproximada.

También probé `console.warn()` y `console.error()`.

Un error puede hacer que una parte del código deje de funcionar.

Una advertencia avisa que algo puede estar mal, pero no siempre detiene la página.


seccion 7

Revisé una imagen panorámica de Medellín:

   Formato JPEG.
   Tamaño aproximado de 135 kB.
   Tiempo de 88 ms.
   Estado 200.

 También revisé `osm-intl`:

   Formato PNG.
   Tamaño de 55 kB.
   Tiempo de 220 ms.
   Estado 200.

También revisé `wikipedia.png`:

   Formato PNG.
   Tamaño de 14.3 kB.
   Tiempo de 73 ms.
   Estado 200.

 Sin caché aparecieron 64 solicitudes y se transfirieron 2.4 MB.

 Con caché aparecieron 60 solicitudes en total y se transfirieron mucho menos datos.

 Con red 3G aparecieron 62 solicitudes y la página tardó mucho más en cargar.

 La imagen más pesada de las que revisé fue la panorámica de Medellín.

 La caché hace que la página cargue más rápido porque algunos archivos ya están guardados en el navegador.

 Probar con una red lenta sirve para ver cómo funciona la página para una persona que no tiene buena conexión.

 Para que una imagen cargue más rápido se puede comprimir, reducir su tamaño o usar formatos más livianos.


seccion 8

 Probé la página en varios tamaños como 320 px, 375 px, 768 px, 1024 px y 1440 px.

 En los tamaños pequeños el contenido se acomodaba para verse mejor en celular.

 En pantallas más grandes había más espacio y la página se veía más parecida a escritorio.

 Las imágenes se seguían viendo bien.

 Es importante probar varios tamaños porque no todas las personas entran desde el mismo dispositivo.

 Así uno puede encontrar problemas antes de entregar la página.



seccion 9


el primer error fue que el CSS no cargaba.

   La página aparecía sin estilos.
   El problema era que en el HTML decía `css`, pero la carpeta realmente se llamaba `CSS`.
   Lo corregí poniendo la ruta correcta.

El segundo error fue con el botón.

   En la consola aparecía un error relacionado con `addEventListener`.
   JavaScript buscaba `btn-saludar`, pero en HTML el botón se llamaba `boton-saludar`.
   Cambié el nombre en JavaScript para que fuera igual.

El tercer error fue con una variable.

   Aparecía `nombreCodr is not defined`.
   El nombre estaba mal escrito.
   Lo cambié por `nombreCoder`.

El cuarto problema fue el logo.

   No se veía en la página.
   El archivo estaba vacío.
   Puse una imagen PNG real y ya se mostró.

Uno de los errores que más entendí fue el del botón, porque JavaScript estaba buscando un id que no existía.

Con el breakpoint pude detener el código y mirar qué estaba pasando antes de que siguiera ejecutándose.

Cuando cambié `visitas` a 99 y recargué, apareció 100 porque el código suma 1.

Cuando borré `visitas`, al recargar volvió a empezar en 1.

 `localStorage` sirve para guardar algunos datos en el navegador.

No se deberían guardar contraseñas ni información sensible ahí.

Las tarjetas se apilan cuando la pantalla llega a 600 px o menos.

Esto pasa por esta regla:

```css
@media (max-width: 600px) {
  .contenido {
    flex-direction: column;
  }
}
```

No basta con mirar solo la consola porque hay problemas que también se pueden ver en Network, en los estilos o directamente mirando la página.


seccion 10

En Chrome se usa Elements y en Firefox se usa Inspector para revisar HTML y CSS.

Los dos tienen consola para ejecutar código y mirar errores.

Los dos tienen una parte de Red para revisar las solicitudes de la página.

Los dos permiten probar tamaños de celular.

En Chrome el localStorage está en Application.

En Firefox está en Almacenamiento.

Cuando provoqué otra vez el error del botón, los dos navegadores mostraron el problema, aunque se veía un poco diferente en cada uno.

Una herramienta de Firefox que me pareció interesante fue el Editor de estilos.

Sirve para mirar y cambiar el CSS de la página directamente.

seccion 11

La herramienta que creo que más voy a usar es DevTools, especialmente la consola y el Inspector.

Me parece útil porque ayuda a encontrar errores y entender mejor lo que está pasando en una página.

Lo más difícil fue encontrar los errores del laboratorio porque no todos estaban en el mismo lugar.

Lo fui resolviendo mirando la consola, el código, Network y haciendo pruebas.

Para alguien que no programa, yo diría que DevTools son herramientas que trae el navegador para mirar cómo está hecha una página.

Sirven para revisar textos, colores, imágenes y errores.

También dejan hacer pruebas sin dañar la página original.
